import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

const links: {
  href: string;
  label: string;
}[] = [
  {
    href: '/#how',
    label: 'How it works',
  },
  {
    href: '/#categories',
    label: 'Categories',
  },
  {
    href: '/#comp',
    label: 'Comparison',
  },
  {
    href: '/#pricing',
    label: 'Pricing',
  },
  {
    href: '/#faq',
    label: 'FAQ',
  },
];

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between gap-4 bg-white p-3 pl-6 rounded-xl w-full">
      <Image
        src="/logo.svg"
        alt="logo"
        width={100}
        height={32}
        className="h-6 w-auto"
      />

      {/* <ul className="flex items-center gap-4">
        <li>
          <a href="#" className="text-sm">
            Home
          </a>
        </li>
      </ul> */}

      <div className="hidden lg:flex lg:justify-center lg:gap-8 lg:items-center">
        {links.map((link) => (
          <Link
            href={link.href}
            key={link.href}
            className="link link-hover text-base text-slate-600"
            title={link.label}
          >
            {link.label}
          </Link>
        ))}
      </div>

      <a
        href="https://tally.so/r/3jleJE"
        className="btn px-6 py-3 font-medium text-white text-base bg-[#215CFE] shadow-md"
      >
        Start hiring
      </a>
    </nav>
  );
}

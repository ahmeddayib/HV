import React from 'react';
import Typography from '../typography';
import Image from 'next/image';

export default function HowItWorks() {
  return (
    <section id="how" className="my-24 container mx-auto max-md:my-16">
      <div className="text-center mb-16 max-md:mb-10">
        <Typography.H6 className="text-[#215CFE] font-normal max-md:text-base">
          How it works
        </Typography.H6>
        <Typography.H2 className="font-semibold max-md:text-2xl">
          Seamless Process
        </Typography.H2>
      </div>

      <div className="flex items-center gap-16 max-w-3xl mx-auto max-md:flex-col max-md:justify-center p-2 max-md:gap-8">
        {/* <div className="shadow-[4px_4px_0_0_#000] w-96 h-72 rounded-lg shrink-0  max-sm:w-full [background-image:'url(/feat1.png)']"></div> */}
        <Image
          src="/feat1.png"
          alt="Free Talent Acquisition and Development"
          width={300}
          height={300}
          className="w-96 h-72 rounded-lg shrink-0  max-sm:w-full object-cover"
        />
        <div>
          <Typography.H3 className=" font-semibold text-4xl text-slate-900 mb-4 max-md:text-xl max-md:mb-2">
            No Sourcing or Training Fee
          </Typography.H3>
          <Typography.B1 className=" text-slate-600 mb-8 max-md:mb-4 max-md:text-sm">
            We&apos;re dedicated to connecting you with an assistant perfectly suited to your requirements.
          </Typography.B1>
          <a
            href="https://tally.so/r/3jleJE"
            className="btn bg-[#215CFE] btn-primary border-none"
          >
            Start hiring
          </a>
        </div>
      </div>

      <div className="flex items-center gap-16 max-w-3xl mx-auto mt-16 max-md:mt-10 max-md:flex-col-reverse max-md:justify-center p-4 max-md:gap-8">
        <div>
          <Typography.H3 className=" font-semibold text-4xl text-slate-900 mb-4 max-md:text-xl max-md:mb-2">
            Ready, Set, Grow!{' '}
          </Typography.H3>
          <Typography.B1 className=" text-slate-600 mb-8 max-md:mb-4 max-md:text-sm">
           Jumpstart your success with our expert-trained assistants.
          </Typography.B1>
          <a
            href="https://tally.so/r/3jleJE"
            className="btn bg-[#215CFE] btn-primary border-none"
          >
            Start hiring{' '}
          </a>
        </div>
        <Image
          src="/feat2.png"
          alt="Free Sourcing, Hiring & Training"
          width={300}
          height={300}
          className="w-96 h-72 rounded-lg shrink-0  max-sm:w-full object-cover"
        />
      </div>
    </section>
  );
}

import Image from 'next/image';
import React from 'react';
import Typography from '../typography';
import Link from 'next/link';

export default function Footer() {
  return (
    <section className="mt-64 relative bg-black py-14 pt-32 max-md:mt-14 max-md:pt-14">
      <div className="absolute -top-3/4 -right-0 bg-[#215CFE] w-[80%] rounded-s-3xl shadow-[-8px_8px_0_0_#6ADAFF] p-14 flex items-start justify-center  gap-8 max-md:hidden">
        <div>
          <Typography.H3 className="text-white font-medium mb-4">
            Elevate Your Business Today
          </Typography.H3>
          <Typography.B1 className="text-white opacity-95 font-normal">
            Discover top-tier virtual assistants and accelerate your journey to success. Join the ranks of businesses thriving with our expert support.
          </Typography.B1>

        </div>
        <div className="shrink-0">
        <a
          href="https://tally.so/r/3jleJE"
          className={`mt-auto px-8 bg-black shadow-[4px_4px_0_0_#fff] btn hover:bg-black active:shadow-[2px_2px_0_0_#fff] hover:scale-105 text-white  border-none transition-transform`}
        >
          Hire now
        </a>

        </div>
      </div>

      <footer className="relative flex items-center flex-wrap justify-between gap-4 w-full max-w-screen-xl mx-auto px-4 max-md:justify-center max-md:gap-8">
        <Image src="/logo-white.svg" alt="logo" width={100} height={100} />

        <div className="flex justify-center gap-12 items-center max-lg:gap-6 max-sm:text-xs flex-wrap">
          <Link className="link link-hover text-white text-sm" href="/tos">
            Terms & conditions
          </Link>
          <Link
            className="link link-hover text-white text-sm"
            href="/privacy-policy"
          >
            Privacy policy
          </Link>
          <Link className="link link-hover text-white text-sm" href={'/'}>
            About
          </Link>
        </div>
        <Typography.B1 className="text-white">
          Contact us at <a href="mailto:info@hirevirtual.co" className="link link-hover">info@hirevirtual.co</a>
        </Typography.B1>
        <div className="flex items-center  gap-2">
          <a className="w-8 h-8 bg-white flex items-center justify-center rounded-full">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              fill="#000000"
              viewBox="0 0 256 256"
            >
              <path d="M247.39,68.94A8,8,0,0,0,240,64H209.57A48.66,48.66,0,0,0,168.1,40a46.91,46.91,0,0,0-33.75,13.7A47.9,47.9,0,0,0,120,88v6.09C79.74,83.47,46.81,50.72,46.46,50.37a8,8,0,0,0-13.65,4.92c-4.31,47.79,9.57,79.77,22,98.18a110.93,110.93,0,0,0,21.88,24.2c-15.23,17.53-39.21,26.74-39.47,26.84a8,8,0,0,0-3.85,11.93c.75,1.12,3.75,5.05,11.08,8.72C53.51,229.7,65.48,232,80,232c70.67,0,129.72-54.42,135.75-124.44l29.91-29.9A8,8,0,0,0,247.39,68.94Zm-45,29.41a8,8,0,0,0-2.32,5.14C196,166.58,143.28,216,80,216c-10.56,0-18-1.4-23.22-3.08,11.51-6.25,27.56-17,37.88-32.48A8,8,0,0,0,92,169.08c-.47-.27-43.91-26.34-44-96,16,13,45.25,33.17,78.67,38.79A8,8,0,0,0,136,104V88a32,32,0,0,1,9.6-22.92A30.94,30.94,0,0,1,167.9,56c12.66.16,24.49,7.88,29.44,19.21A8,8,0,0,0,204.67,80h16Z"></path>
            </svg>
          </a>
        </div>
      </footer>
    </section>
  );
}

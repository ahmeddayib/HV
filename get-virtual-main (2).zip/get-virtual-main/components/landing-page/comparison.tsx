import Link from 'next/link';
import Typography from '../typography';
import React from 'react';

export default function Comparison() {
  return (
    <section
      id="comp"
      className="mx-auto flex items-center flex-col justify-center px-4 max-lg:px-2 max-md:px-1 mb-24  max-w-screen-xl"
    >
      <Typography.H2 className="font-semibold text-center leading-relaxed mt-24 max-md:mt-6 max-lg:text-4xl max-md:leading-relaxed mb-20 max-md:text-2xl">
        HireVirtual{' '}
        <span className="inline-block bg-[#215CFE] text-white rounded-lg -rotate-3 px-4 shadow-[4px_4px_0_0_#000] hover:rotate-3 transition-transform max-md:px-2 ">
          vs
        </span>{' '}
        Competitors
      </Typography.H2>

      <div className="flex gap-2 max-md:gap-1 max-sm:gap-0 items-start">
        <Col
          title={<p className="opacity-0">Compatetors</p>}
          values={[
            'Cost',
            'Turnaround Time',
            'Commitment',
            'Revisions',
            'Top Talent',
            'Start Time',
            'Pricing Structure',
          ]}
        />
        <Col
          title="HireVirtual"
          values={[
            '$',
            'Few Days',
            'Low',
            'Unlimited',
            'Yes',
            'Today',
            'No Contracts',
          ]}
          type="main"
        />
        <Col
          title="Freelance Platforms"
          values={[
            '$',
            'Weeks',
            'High',
            'Limited',
            'No',
            'Days',
            'Get what you pay',
          ]}
        />
        <Col
          title="Employees"
          values={[
            '$$$',
            'Weeks',
            'High',
            'Limited',
            'Yes',
            'Weeks',
            'Flexible',
          ]}
        />
        <Col
          title="Traditional Agencies"
          values={[
            '$$$$',
            'Weeks+',
            'Very High',
            'Limited',
            'Yes',
            'Weeks+',
            'High (with fees)',
          ]}
        />
      </div>
    </section>
  );
}

function Col({
  type,
  title,
  values,
}: {
  type?: 'main' | 'sub';
  title: string | React.ReactNode;
  values: string[];
}) {
  return (
    <div
      className={`flex flex-col gap-6 p-4 rounded-lg items-center py-8 max-md:p-2 max-sm:p-1 text-center ${
        type === 'main'
          ? 'bg-[#215CFE] shadow-[4px_4px_0_0_#000] text-white px-8 max-sm:px-1'
          : ''
      }`}
    >
      <Typography.H6 className="mb-4 max-md:text-base max-sm:text-xs font-medium">
        {title}
      </Typography.H6>
      {values.map((value) => (
        <Typography.B1
          key={value}
          className="max-md:text-sm max-sm:text-xs max-[400px]:text-[10px]"
        >
          {value}
        </Typography.B1>
      ))}

      {type === 'main' && (
        <Link
        className="bg-black shadow-[4px_4px_0_0_#fff] btn hover:bg-[#215CFE] hover:text-white active:shadow-[2px_2px_0_0_#fff] text-white text-base mt-4"
        href="https://tally.so/r/3jleJE"
      >
        Hire Now
      </Link>
      
      )}
    </div>
  );
}

import Image from 'next/image';
import Typography from '../typography';

export default function CategoryCard({
  title,
  description,
  image,
  number,
}: {
  title: string;
  description: string;
  image?: string;
  number: number;
}) {
  return (
    <div className="relative z-10 ">
      {/* <div className=" bg-gray-200 w-full h-44 rounded-lg mb-2"></div> */}
      <Image
        src={image}
        alt={title}
        width={300}
        height={200}
        className=" w-full h-44 rounded-lg mb-2 object-cover"
      />
      <div className="flex gap-4">
        <div className="bg-[#215CFE] text-white shadow-[2px_2px_0_0_#000] w-8 h-8 rounded-full flex items-center justify-center shrink-0">
          {number}
        </div>
        <div>
          <Typography.H5 className="font-medium mb-2 max-md:text-lg max-md:mb-1">
            {title}
          </Typography.H5>
          <Typography.B1 className="text-slate-600 max-md:text-sm">
            {description}
          </Typography.B1>
        </div>
      </div>
    </div>
  );
}

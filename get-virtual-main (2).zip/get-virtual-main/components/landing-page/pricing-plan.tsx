import React from 'react';
import Typography from '../typography';

interface Props {
  type: 'main' | 'sub';
  title: string;
  price: string;
  description: string;
  descriptionClass: string;
  features: string[];
  featuresClass: string;
}

export default function PricingPlan({
  price,
  description,
  descriptionClass,
  features,
  featuresClass,
  title,
  type,
}: Props) {
  return (
    <div
      className={`border p-8 rounded-lg text-center flex flex-col items-center max-lg:p-4   ${
        type === 'main'
          ? 'bg-[#215CFE] shadow-[4px_4px_0_0_#000] border-none text-white'
          : ''
      }`}
    >
      <Typography.B2
        className={`mb-5 uppercase tracking-widest max-md:text-xs ${
          type === 'main' ? 'text-white' : 'text-[#215CFE]'
        }`}
      >
        {title}
      </Typography.B2>

      <p className="text-4xl font-bold mb-8 max-lg:text-3xl">
        ${price}{' '}
        <span className="text-base font-normal max-lg:text-sm">/bi-weekly</span>
      </p>

      <Typography.B1
        className={`${
          type === 'main' ? 'text-white opacity-95' : 'text-gray-600'
        } font-normal mb-6 max-lg:text-sm ${descriptionClass}`} // Apply the descriptionClass
      >
        {description}
      </Typography.B1>

      <ul className="flex flex-col gap-2 items-start justify-center mb-8">
        {features.map((feature) => (
          <li className="flex gap-2 items-start" key={feature}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              fill={type === 'main' ? '#fff' : `#495057`}
              viewBox="0 0 256 256"
              className="shrink-0"
            >
              <path d="M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z"></path>
            </svg>
            <span
              className={`${
                type === 'main' ? 'text-white opacity-95' : 'text-gray-600'
              } text-left font-normal max-lg:text-sm ${featuresClass}`} // Apply the featuresClass
            >
              {feature}
            </span>
          </li>
        ))}
      </ul>

      <a
        href="https://tally.so/r/3jleJE"
        className={`mt-auto px-8 ${
          type === 'main'
            ? `bg-black shadow-[4px_4px_0_0_#fff] btn hover:bg-black active:shadow-[2px_2px_0_0_#fff] text-white  border-none`
            : 'btn btn-outline'
        }`}
      >
        Hire now
      </a>
    </div>
  );
}

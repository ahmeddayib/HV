import React from 'react';
import Typography from '../typography';
import CategoryCard from './category-card';

export default function Categories() {
  return (
    <section className="py-14 overflow-x-hidden bg-[#F2F5F5]" id="categories">
      <div>
        <div className="text-center mb-16 max-w-5xl mx-auto max-md:mb-8 p-4">
          <Typography.H6 className="text-[#215CFE] font-normal max-md:text-base">
            Specialties
          </Typography.H6>
          <Typography.H2 className="font-semibold max-md:text-2xl">
            The best assistants in all specialties to help you expand and
            develop
          </Typography.H2>
          <Typography.B1 className="text-slate-600 mt-4 max-md:text-sm ">
            The best assistants in all specialties to help you expand and
            develop The best assistants in all specialties to help you expand
            and develop
          </Typography.B1>
        </div>

        <div className="relative">
          <div className="grid grid-cols-3 gap-4  max-w-screen-lg mx-auto max-md:grid-cols-1 p-4">
            <CategoryCard
              image="/specialities/ma.png"
              number={1}
              title="Marketing Assistants"
              description="Boost your social media impact with skilled marketing mavens."
            />
            <CategoryCard
              number={2}
              title="Virtual Assistants"
              image="/specialities/va.png"
              description="Empower your business expansion with efficient virtual assistance."
            />
            <CategoryCard
              number={3}
              image="/specialities/da.png"
              title="Design Assistants"
              description="Unleash creative brilliance with our expert design support."
            />
          </div>
          <div className="bg-white absolute -bottom-6 w-full h-40 scale-x-150 max-md:hidden"></div>
        </div>
      </div>
    </section>
  );
}

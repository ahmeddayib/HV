import Link from 'next/link';
import Navbar from './navbar';

function Hero() {
  return (
    <header className="flex flex-col items-center justify-center text-center gap-12  px-8 pb-24 pt-6 bg-hero-pattern bg-center max-md:px-6 max-sm:px-4 max-sm:pt-4 bg-no-repeat bg-cover">
      <Navbar />

      <h1 className="text-5xl font-bold text-white leading-relaxed mt-14 max-md:mt-6 max-lg:text-4xl max-md:leading-relaxed max-md:text-3xl max-w-7xl">
        Maximize Your Business{' '}
        <span className="inline-block bg-white text-[#215CFE] rounded-lg -rotate-3 px-4 shadow-[4px_4px_0_0_#000] hover:rotate-3 transition-transform max-md:px-2 ">
          Efficiency
        </span>{' '}
        with Skilled Overseas Virtual Assistants at Unbeatable{' '}
        <span className={'relative'}>
          Rates
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="#ffffff"
            viewBox="0 0 256 256"
            className="absolute -right-6 -top-2 w-8 h-8 max-md:w-6 max-md:h-6 max-md:-right-4 max-md:-top-2"
          >
            <path d="M208,144a15.78,15.78,0,0,1-10.42,14.94l-51.65,19-19,51.61a15.92,15.92,0,0,1-29.88,0L78,178l-51.62-19a15.92,15.92,0,0,1,0-29.88l51.65-19,19-51.61a15.92,15.92,0,0,1,29.88,0l19,51.65,51.61,19A15.78,15.78,0,0,1,208,144ZM152,48h16V64a8,8,0,0,0,16,0V48h16a8,8,0,0,0,0-16H184V16a8,8,0,0,0-16,0V32H152a8,8,0,0,0,0,16Zm88,32h-8V72a8,8,0,0,0-16,0v8h-8a8,8,0,0,0,0,16h8v8a8,8,0,0,0,16,0V96h8a8,8,0,0,0,0-16Z"></path>
          </svg>
        </span>
      </h1>

       <p className="text-white font-semibold text-lg mb-10 max-w-screen-lg text-shadow">
        We provide comprehensive support in recruiting, training, and supervising virtual assistants for your business growth.
      </p>

      <div className="flex items-center gap-8">
      <Link
  className="bg-black shadow-[4px_4px_0_0_#fff] hover:bg-blue-700 btn text-white lg:px-14 px-8 max-md:text-base text-lg lg:btn-lg transform transition-transform duration-300 hover:scale-105 active:scale-95 hover:shadow-[4px_4px_0_0_#fff] active:shadow-[2px_2px_0_0_#fff]"
  href="https://tally.so/r/3jleJE"
>
  Start hiring
</Link>


        <a
          className="text-white flex items-center gap-2 max-md:text-sm text-lg"
          href="#categories"
        >
          Learn more{' '}
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            fill="#fff"
            viewBox="0 0 256 256"
            className="max-md:w-4 max-md:h-4"
          >
            <path d="M205.66,149.66l-72,72a8,8,0,0,1-11.32,0l-72-72a8,8,0,0,1,11.32-11.32L120,196.69V40a8,8,0,0,1,16,0V196.69l58.34-58.35a8,8,0,0,1,11.32,11.32Z"></path>
          </svg>
        </a>
      </div>
    </header>
  );
}

export default Hero;

import Typography from '../typography';
import PricingPlan from './pricing-plan';

export default function Pricing() {
  return (
    <section id="pricing" className="py-16">
      <div className="text-center mb-16 max-w-5xl mx-auto">
        <Typography.H6 className="text-[#215CFE] font-normal max-md:text-base">
          Pricing
        </Typography.H6>
        <Typography.H2 className="font-semibold max-md:text-2xl">
          Pricing plan for every need
        </Typography.H2>
      </div>

      <div className="grid grid-cols-3 gap-4 max-w-screen-xl px-4 mx-auto max-sm:grid-cols-1">
      <PricingPlan
          type="sub"
          title="Marketing & Design"
          price="1229"
          description="Boost creativity and outreach – ideal for innovative startups and design-focused businesses."
          descriptionClass="text-lg font-medium text-slate-700" // Added class for description
          features={[
            'All features from the standard Virtual Assistant Plan',
            'Expertise in Advanced Marketing Strategies',
            'Professional Graphic Design Skills',
          ]}
          featuresClass="text-m font-normal text-slate-600" // Added class for features
        />
        <PricingPlan
          title="Virtual Assistant"
          type="main"
          description="Elevate your venture – perfect for solo entrepreneurs and growing teams."
          descriptionClass="text-white font-medium mb-6 max-lg:text-sm" // Added class for description
          price="729"
          features={[
            'Efficient Administrative and Office Support',
            'Email Management and Correspondence Handling',
            'Calendar Scheduling and Appointment Coordination',
            'Data Entry and Document Management'
          ]}
          featuresClass="text-m font-normal text-slate-600" // Added class for features
        />
        <PricingPlan
          title="Enterprise"
          type="sub"
          description="The ultimate solution for established companies and large-scale operations."
          descriptionClass="text-lg font-medium text-slate-700" // Added class for description
          price="1729"
          features={[
            'A Tailored Solution Covering All Business Aspects',
            'Seamless Integration with Your Business Processes',
            'Expertise Across Multiple Domains – Marketing, Design, Admin, and More',
            'Book a Personalized Call for a Custom Solution Fit'
          ]}
          featuresClass="text-m font-normal text-slate-600" // Added class for features
        />
      </div>
    </section>
  );
}

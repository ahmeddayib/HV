'use client';

import { useRef, useState } from 'react';
import type { JSX } from 'react';

// <FAQ> component is a lsit of <Item> component
// Just import the FAQ & add your FAQ content to the const faqList arrayy below.

interface FAQItemProps {
  question: string;
  answer: JSX.Element;
}

const faqList: FAQItemProps[] = [
  {
    question: 'How does hiring offshore talent save me money?',
    answer: (
      <div>
        Hiring offshore talent is cost-effective due to lower living costs and wages in other regions, allowing you to access quality services at a reduced cost.
      </div>
    ),
  },
  {
    question: 'What kind of tasks can I delegate to an offshore assistant?',
    answer: (
      <div>
       Offshore assistants can handle a variety of tasks, from administrative duties and digital marketing to graphic design and web development.
      </div>
    ),
  },
  {
    question: 'Is there a minimum commitment period for hiring an offshore assistant?',
    answer: (
      <div>
        There is no minimum commitment. Our flexible plans let you hire assistance monthly, adjusting as your business needs change.      
      </div>
    ),
  },
  {
    question: 'How do you ensure the quality of offshore talent?',
    answer: (
      <div>
        We select only qualified professionals and provide ongoing training to maintain high service standards.      
      </div>
    ),
  },
  {
    question: 'Are there any additional costs involved in hiring offshore talent?',
    answer: (
      <div>
        No, there are no hidden costs. Our pricing plans are transparent and all-inclusive, covering the assistant&apos;s salary, administrative costs, and any other associated fees. You pay only what is stated in your chosen plan.
      </div>
    ),
  },
  {
    question: 'How quickly can I start working with an offshore assistant?',
    answer: (
      <div>
        We strive for a quick turnaround. Once you sign up and specify your requirements, we typically match you with a suitable assistant within a few days, allowing you to start delegating tasks almost immediately.
      </div>
    ),
  },
];

const FaqItem = ({ item }: { item: FAQItemProps }) => {
  const accordion = useRef(null);
  const [isOpen, setIsOpen] = useState(false);

  return (
    <li>
      <button
        className="relative flex gap-2 items-center w-full py-5 text-base font-semibold text-left border-t md:text-lg border-base-content/10"
        onClick={(e) => {
          e.preventDefault();
          setIsOpen(!isOpen);
        }}
        aria-expanded={isOpen}
      >
        <span
          className={`flex-1 text-base-content ${
            isOpen ? 'text-[#215CFE]' : ''
          }`}
        >
          {item?.question}
        </span>
        <svg
          className={`flex-shrink-0 w-4 h-4 ml-auto fill-current`}
          viewBox="0 0 16 16"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            y="7"
            width="16"
            height="2"
            rx="1"
            className={`transform origin-center transition duration-200 ease-out ${
              isOpen && 'rotate-180'
            }`}
          />
          <rect
            y="7"
            width="16"
            height="2"
            rx="1"
            className={`transform origin-center rotate-90 transition duration-200 ease-out ${
              isOpen && 'rotate-180 hidden'
            }`}
          />
        </svg>
      </button>

      <div
        ref={accordion}
        className={`transition-all duration-300 ease-in-out opacity-80 overflow-hidden`}
        style={
          isOpen
            ? { maxHeight: accordion?.current?.scrollHeight, opacity: 1 }
            : { maxHeight: 0, opacity: 0 }
        }
      >
        <div className="pb-5 leading-relaxed">{item?.answer}</div>
      </div>
    </li>
  );
};

const FAQ = () => {
  return (
    <section className="bg-[#F2F5F5]" id="faq">
      <div className="py-24 px-8 max-w-7xl mx-auto flex flex-col md:flex-row gap-12">
        <div className="flex flex-col text-left basis-1/2">
          <p className="inline-block font-normal text-[#215CFE] mb-1">FAQ</p>
          <p className="sm:text-4xl text-3xl font-semibold text-base-content">
            Frequently Asked Questions
          </p>
        </div>

        <ul className="basis-1/2">
          {faqList.map((item, i) => (
            <FaqItem key={i} item={item} />
          ))}
        </ul>
      </div>
    </section>
  );
};

export default FAQ;

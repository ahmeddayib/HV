import React from 'react';

function Typography() {
  return <div></div>;
}

function H1({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h1
      className={`lg:text-[56px] md:text-[48px] sm:text-[36px] text-[30px] leading-tight tracking-tight font-bold ${className}`}
    >
      {children}
    </h1>
  );
}

function H2({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h2
      className={`text-[40px] leading-tight tracking-tight font-bold ${className}`}
    >
      {children}
    </h2>
  );
}

function H3({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h3
      className={`text-[28px] leading-tight tracking-tight font-bold ${className}`}
    >
      {children}
    </h3>
  );
}

function H4({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h4
      className={`text-[26px] leading-tight tracking-tight font-bold ${className}`}
    >
      {children}
    </h4>
  );
}

function H5({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h5
      className={`text-[21px] leading-snug tracking-tight font-bold ${className}`}
    >
      {children}
    </h5>
  );
}

function H6({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h6
      className={`sm:text-[18px] text-[16px] leading-snug font-bold ${className}`}
    >
      {children}
    </h6>
  );
}

function B1({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <p className={`text-[16px] leading-6 font-normal ${className}`}>
      {children}
    </p>
  );
}

function B2({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <p
      className={`text-[14px] leading-5 tracking-tight font-normal ${className}`}
    >
      {children}
    </p>
  );
}

function B3({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <p
      className={`text-[12px] leading-4 tracking-tight font-normal ${className}`}
    >
      {children}
    </p>
  );
}

function L1({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <p className={`text-[16px] leading-6 font-medium ${className}`}>
      {children}
    </p>
  );
}

function L2({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <p className={`text-[14px] leading-5 font-medium ${className}`}>
      {children}
    </p>
  );
}

function L3({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <p className={`text-[12px] leading-4 font-medium ${className}`}>
      {children}
    </p>
  );
}

Typography.H1 = H1;
Typography.H2 = H2;
Typography.H3 = H3;
Typography.H4 = H4;
Typography.H5 = H5;
Typography.H6 = H6;
Typography.B1 = B1;
Typography.B2 = B2;
Typography.B3 = B3;
Typography.L1 = L1;
Typography.L2 = L2;
Typography.L3 = L3;

export default Typography;

import FAQ from '@/components/landing-page/FAQ';
import { Analytics } from '@vercel/analytics/react';
import Categories from '@/components/landing-page/categories';
import Comparison from '@/components/landing-page/comparison';
import Footer from '@/components/landing-page/footer';
import Hero from '@/components/landing-page/hero';
import HowItWorks from '@/components/landing-page/how-it-works';
import Pricing from '@/components/landing-page/pricing';
export default function Page() {
  return (
    <>
      {/* <Header /> */}

      <main>
        <Hero />
        <HowItWorks />
        <Categories />
        <Comparison />
        <Pricing />
        <FAQ />
        <Footer />
        <Analytics />
      </main>
    </>
  );
}

import Link from "next/link";
import { getSEOTags } from "@/libs/seo";
import config from "@/config";

// CHATGPT PROMPT TO GENERATE YOUR PRIVACY POLICY — replace with your own data 👇

// 1. Go to https://chat.openai.com/
// 2. Copy paste bellow
// 3. Replace the data with your own (if needed)
// 4. Paste the answer from ChatGPT directly in the <pre> tag below

// You are an excellent lawyer.

// I need your help to write a simple privacy policy for my website. Here is some context:
// - Website: https://shipfa.st
// - Name: ShipFast
// - Description: A JavaScript code boilerplate to help entrepreneurs launch their startups faster
// - User data collected: name, email and payment information
// - Non-personal data collection: web cookies
// - Purpose of Data Collection: Order processing
// - Data sharing: we do not share the data with any other parties
// - Children's Privacy: we do not collect any data from children
// - Updates to the Privacy Policy: users will be updated by email
// - Contact information: marc@shipfa.st

// Please write a simple privacy policy for my site. Add the current date.  Do not add or explain your reasoning. Answer:

export const metadata = getSEOTags({
  title: `Privacy Policy | ${config.appName}`,
  canonicalUrlRelative: "/privacy-policy",
});

const PrivacyPolicy = () => {
  return (
    <main className="max-w-xl mx-auto">
      <div className="p-5">
        <Link href="/" className="btn btn-ghost">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
            className="w-5 h-5"
          >
            <path
              fillRule="evenodd"
              d="M15 10a.75.75 0 01-.75.75H7.612l2.158 1.96a.75.75 0 11-1.04 1.08l-3.5-3.25a.75.75 0 010-1.08l3.5-3.25a.75.75 0 111.04 1.08L7.612 9.25h6.638A.75.75 0 0115 10z"
              clipRule="evenodd"
            />
          </svg>{" "}
          Back
        </Link>
        <h1 className="text-3xl font-extrabold pb-6">
          Privacy Policy for {config.appName}
        </h1>

        <pre
          className="leading-relaxed whitespace-pre-wrap"
          style={{ fontFamily: "sans-serif" }}
        >
          {`
Privacy Policy for HireVirtual

Last Updated: 11/12/2023

1. Introduction

Welcome to HireVirtual. We are committed to protecting the privacy and security of our users and visitors. This Privacy Policy outlines our practices concerning the collection, use, and disclosure of your information when you use our service.

2. Information We Collect

We may collect personal information that you provide to us, such as your name, email address, phone number, and payment information. We also collect non-personal information such as browser type, operating system, and the pages you visit on our site.

3. How We Use Your Information

Your information is used to provide and improve our services, process transactions, communicate with you, and for security purposes. We may also use your information for marketing purposes with your consent.

4. Data Sharing and Disclosure

We do not sell or rent personal information to third parties. We may share information with service providers who perform services on our behalf, such as payment processing. We may also disclose information if required by law or to protect our rights.

5. Data Security

We implement a variety of security measures to maintain the safety of your personal information. However, no method of transmission over the Internet is entirely secure.

6. Your Rights and Choices

You have certain rights regarding the personal information we hold about you. You can request access, correction, or deletion of your personal data, and you may also have the right to object to or restrict certain processing.

7. Third-Party Links

Our service may contain links to third-party websites. This Privacy Policy does not apply to those external websites, and we recommend reviewing their privacy policies.`
}
        </pre>
      </div>
    </main>
  );
};

export default PrivacyPolicy;
